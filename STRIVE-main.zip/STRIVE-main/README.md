baseline.py provides the code for running GPT-4 Turbo using Baseline Method.

Prompt_gen1.py provides the code for generating multiple strength, and weakness pairs from the context and question for Thinking Module1.


Prompt_judge1.py provides the code for choosing best strength, weakness pairs from the context and question and also evaluate the metric scores for Thinking Module1.


extract1.py gives the code to extract strength and weakness pairs from the context and question for Thinking Module1.
.


Prompt_gen2.py provides the code for generating multiple strength, and weakness pairs from the context and question for Thinking Module2.

Prompt_judge2.py provides the code for choosing best strength, weakness pairs from the context and question and also evaluate the metric scores for Thinking Module2.

extract2.py gives the code to extract strength and weakness pairs from the context and question for Thinking Module2.
